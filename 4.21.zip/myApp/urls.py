from django.conf.urls import url
from django.urls import path
from . import views

app_name = 'visit'
urlpatterns = [
    # url('bar/', views.ChartView.as_view(), name='bar'),    #不需要
    # url('index', views.IndexView.as_view(), name='demo'),    #不需要
    path('<str:data>',views.expt,name='expt'),
]