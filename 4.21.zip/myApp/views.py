from django.shortcuts import render

from pymongo import MongoClient



from django.http import HttpResponse


client = MongoClient('localhost',27017)
db_douyin = client.douyin
db_kuaishou = client.kuaishou
db_huoshan = client.huoshan

def index(request):
    return render(request,'index.html')


def search(request):
    if request.method == 'POST':
        #抖音排行
        data = request.POST.get('keyword')
        lst_douyin = list(db_douyin[data].find())
        d = {}
        fans = {}
        zans = {}
        for item in lst_douyin:
            a1 = 1.05
            a2 = 1.001
            a3 = 1.1
            a4 = 1.005
            b1 = 0.4
            b2 = 0.45
            b3 = 0.05
            b4 = 0.1
            demo = ((((2 / (1 + a1 ** -item['fans_count'])) - 1) * 100 * b1) + (((2 / (1 + a2 ** -item['zan_count'])) - 1) * 100 * b2)+ (((2 / (1 + a3 ** -item['aweme_count'])) - 1) * 100 * b3) + (((2 / (1 + a4 ** -item['aweme_favoriting_count'])) - 1) * 100 * b4))
            #计算评估值
            d[item['user_name']] = demo
            #粉丝数的排行
            fans[item['user_name']] = item['fans_count']
            #点赞数的排行
            zans[item['user_name']] = item['zan_count']

        #抖音--按照评估值排行
        demo_order = sorted(d.items(),key=lambda x:x[1],reverse=True)
        #抖音--按照粉丝数排行
        fans_order = sorted(fans.items(),key=lambda x:x[1],reverse=True)
        #抖音--按照点赞数排行
        zans_order = sorted(zans.items(),key=lambda x:x[1],reverse=True)


        #火山排行
        lst_huoshan = list(db_huoshan[data].find())
        d_huoshan = {}
        fans_huoshan = {}
        zans_huoshan = {}
        for i in lst_huoshan:
            a1 = 1.05
            a2 = 1.001
            a3 = 1.1
            a4 = 1.005
            b1 = 0.4
            b2 = 0.45
            b3 = 0.05
            b4 = 0.1
            demo = ((((2 / (1 + a1 ** -i['fans_count'])) - 1) * 100 * b1) + (((2 / (1 + a2 ** -i['zan_count'])) - 1) * 100 * b2)+ (((2 / (1 + a3 ** -i['zhibo_count'])) - 1) * 100 * b3) + (((2 / (1 + a4 ** -i['zhibo_time'])) - 1) * 100 * b4))
        #     #计算评估值
            d_huoshan[i['user_name']] = demo
        #     #粉丝数的排行
            fans_huoshan[i['user_name']] = i['fans_count']
        #     #点赞数的排行
            zans_huoshan[i['user_name']] = i['zan_count']
        # #火山--按照评估值排行
        demo_huoshan_order = sorted(d_huoshan.items(),key=lambda x:x[1],reverse=True)
        # print(demo_huoshan_order)
        # #火山--按照粉丝数排行
        fans_huoshan_order = sorted(fans_huoshan.items(),key=lambda x:x[1],reverse=True)
        # #火山--按照点赞数排行
        zans_huoshan_order = sorted(zans_huoshan.items(),key=lambda x:x[1],reverse=True)

        #快手排行
        lst_kuaishou = list(db_kuaishou[data].find())
        fans_kuaishou = {}
        for i in lst_kuaishou:
            fans_kuaishou[i['user_name']] = i['fans_count']

        fans_kuaishou_order = sorted(fans_kuaishou.items(), key=lambda x: x[1], reverse=True)

        return render(request,'show.html',{'lst_douyin':demo_order[:20],'data':data,'fans_order':fans_order[:10],'zans_order':zans_order[:10],
                                           'lst_huoshan':demo_huoshan_order[:10],'fans_huoshan_order':fans_huoshan_order[:10],'zans_huoshan_order':zans_huoshan_order[:10],
                                           'lst_kuaishou':fans_kuaishou_order[:10]})
    return HttpResponse('failed')


def detail(request,username,data):
    lst_douyin = list(db_douyin[data].find())

    for item in lst_douyin:
        # print(type(item))
        d = {}
        if item['user_name'] == username:
            a1 = 1.05
            a2 = 1.001
            a3 = 1.1
            a4 = 1.005
            b1 = 0.4
            b2 = 0.45
            b3 = 0.05
            b4 = 0.1
            demo = ((((2 / (1 + a1 ** -item['fans_count'])) - 1) * 100 * b1) + (
                        ((2 / (1 + a2 ** -item['zan_count'])) - 1) * 100 * b2) + (
                                ((2 / (1 + a3 ** -item['aweme_count'])) - 1) * 100 * b3) + (
                                ((2 / (1 + a4 ** -item['aweme_favoriting_count'])) - 1) * 100 * b4))
            # 把评估值和名字对应上并且传递参数。
            d[item['user_name']] = demo
            return render(request, 'detail.html',{'username':username,'item':item,'demo':demo})


def detail_huoshan(request,username,data):
    lst_huoshan = list(db_huoshan[data].find())

    for item in lst_huoshan:
        # print(type(item))
        d = {}
        if item['user_name'] == username:
            a1 = 1.05
            a2 = 1.001
            a3 = 1.1
            a4 = 1.005
            b1 = 0.4
            b2 = 0.45
            b3 = 0.05
            b4 = 0.1
            demo = ((((2 / (1 + a1 ** -item['fans_count'])) - 1) * 100 * b1) + (
                        ((2 / (1 + a2 ** -item['zan_count'])) - 1) * 100 * b2) + (
                                ((2 / (1 + a3 ** -item['zhibo_count'])) - 1) * 100 * b3) + (
                                ((2 / (1 + a4 ** -item['zhibo_time'])) - 1) * 100 * b4))
            # 把评估值和名字对应上并且传递参数。
            d[item['user_name']] = demo
            return render(request, 'detail_huoshan.html',{'username':username,'item':item,'demo':demo})


def detail_kuaishou(request,username,data):
    lst_kuaishou = list(db_kuaishou[data].find())
    for item in lst_kuaishou:
        d = {}
        if item['user_name'] == username:
            demo = item['fans_count']
            d[item['user_name']] = demo
            return render(request,'detail_kuaishou.html',{'username':username,'item':item,'demo':demo})


def show_huoshan(request):
    return render(request,'show_huoshan.html')

def show_picture(request):
    pass








#可视化
def expt(request,data):
    #查数据库,只取前10个
    lst_douyin = list(db_douyin[data].find())
    d = {}
    fans = {}
    zans = {}
    for item in lst_douyin[:]:
        a1 = 1.05
        a2 = 1.001
        a3 = 1.1
        a4 = 1.005
        b1 = 0.4
        b2 = 0.45
        b3 = 0.05
        b4 = 0.1
        demo = ((((2 / (1 + a1 ** -item['fans_count'])) - 1) * 100 * b1) + (
                    ((2 / (1 + a2 ** -item['zan_count'])) - 1) * 100 * b2) + (
                            ((2 / (1 + a3 ** -item['aweme_count'])) - 1) * 100 * b3) + (
                            ((2 / (1 + a4 ** -item['aweme_favoriting_count'])) - 1) * 100 * b4))
        # 计算评估值
        d[item['user_name']] = demo
        # 粉丝数的排行
        fans[item['user_name']] = item['fans_count']
        # 点赞数的排行
        zans[item['user_name']] = item['zan_count']


        #抖音--按照评估值排行
    demo_order = sorted(d.items(),key=lambda x:x[1],reverse=True)
    #抖音--按照粉丝数排行
    fans_order = sorted(fans.items(),key=lambda x:x[1],reverse=True)
    #抖音--按照点赞数排行
    zans_order = sorted(zans.items(),key=lambda x:x[1],reverse=True)
    # print(demo_order[:20])
    for j in demo_order[:20]:
        if j[1] < 99.99999999993000:
            name = j[0]

    #拿出x轴
    x = []
    for item in d.keys():
        print(item)
        x.append(item)

    #y轴粉丝
    y_fans = []
    for item in fans.values():
        y_fans.append(item)

    #y轴点赞
    y_zans = []
    for item in zans.values():
        y_zans.append(item)

    return render(request,'demo.html',{'xAxis':x,'y_fans':y_fans,'y_zans':y_zans})




